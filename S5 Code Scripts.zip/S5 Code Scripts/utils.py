import os
import torch
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator  # 导入整数刻度定位器
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, datasets
import config


def get_data_loaders():
    """
    创建训练和测试数据加载器
    
    Returns:
        train_loader: 训练数据加载器
        test_loader: 测试数据加载器
        num_classes: 类别数量
    """
    # 使用config中的参数进行数据增强
    data_transforms = {
        'train': transforms.Compose([
            transforms.Resize(config.IMG_SIZE),  # 先调整到较大尺寸
            transforms.RandomCrop(config.CROP_SIZE),  # 随机裁剪
            transforms.RandomHorizontalFlip(p=config.RANDOM_HORIZONTAL_FLIP_PROB),
            transforms.RandomVerticalFlip(p=config.RANDOM_VERTICAL_FLIP_PROB),
            transforms.RandomRotation(config.RANDOM_ROTATION_DEGREES),
            transforms.ColorJitter(
                brightness=config.COLOR_JITTER['brightness'],
                contrast=config.COLOR_JITTER['contrast'],
                saturation=config.COLOR_JITTER['saturation'],
                hue=config.COLOR_JITTER['hue']
            ),
            transforms.ToTensor(),
            transforms.Normalize(config.MEAN, config.STD),
            transforms.RandomErasing(
                p=config.RANDOM_ERASING_PROB,
                scale=config.RANDOM_ERASING_SCALE
            )
        ]),
        'test': transforms.Compose([
            transforms.Resize(config.IMG_SIZE),
            transforms.CenterCrop(config.CROP_SIZE),  # 中心裁剪确保一致性
            transforms.ToTensor(),
            transforms.Normalize(config.MEAN, config.STD)
        ]),
    }

    # 加载数据集
    train_dataset = datasets.ImageFolder(
        root=config.TRAIN_DIR,
        transform=data_transforms['train']
    )
    
    test_dataset = datasets.ImageFolder(
        root=config.TEST_DIR,
        transform=data_transforms['test']
    )
    
    # 优化数据加载性能
    train_loader = DataLoader(
        train_dataset, 
        batch_size=config.BATCH_SIZE,
        shuffle=True,
        num_workers=config.NUM_WORKERS,
        pin_memory=config.PIN_MEMORY,
        prefetch_factor=config.PREFETCH_FACTOR if config.NUM_WORKERS > 0 else None,
        persistent_workers=True if config.NUM_WORKERS > 0 else False
    )
    
    test_loader = DataLoader(
        test_dataset, 
        batch_size=config.BATCH_SIZE,
        shuffle=False,
        num_workers=config.NUM_WORKERS,
        pin_memory=config.PIN_MEMORY,
        prefetch_factor=config.PREFETCH_FACTOR if config.NUM_WORKERS > 0 else None,
        persistent_workers=True if config.NUM_WORKERS > 0 else False
    )
    
    num_classes = len(train_dataset.classes)
    
    print(f"类别数量: {num_classes}")
    print(f"类别: {', '.join(train_dataset.classes)}")
    print(f"训练样本数: {len(train_dataset)}")
    print(f"测试样本数: {len(test_dataset)}")
    
    return train_loader, test_loader, num_classes


def save_checkpoint(state, filename):
    """
    保存模型检查点
    
    Args:
        state: 包含模型状态的字典
        filename: 保存路径
    """
    torch.save(state, filename)
    print(f"保存检查点: {filename}")


def plot_metrics(train_losses, train_accs, val_losses, val_accs, model_name, save_dir):
    """
    绘制训练过程中的损失和准确率图
    
    Args:
        train_losses: 训练损失列表
        train_accs: 训练准确率列表
        val_losses: 验证损失列表
        val_accs: 验证准确率列表
        model_name: 模型名称
        save_dir: 保存目录
    """
    # 获取实际训练的轮数
    actual_epochs = len(train_losses)
    if actual_epochs == 0:
        print(f"模型 {model_name} 没有有效的训练数据点，无法生成图表。")
        return
    
    epochs_range = list(range(1, actual_epochs + 1))
    
    # 将准确率转换为百分比显示
    train_accs_percent = [acc * 100 for acc in train_accs]
    val_accs_percent = [acc * 100 for acc in val_accs]
    
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(11, 9), sharex=True)
    
    # --- 绘制损失曲线 ---
    ax1.set_title(f'Model: {model_name} - Loss Curve', fontsize=14, weight='bold')
    ax1.set_ylabel('Loss (Cross Entropy)', fontsize=12)
    ax1.grid(True, linestyle=':', linewidth=0.6, alpha=0.7)
    
    # 训练损失
    ax1.plot(epochs_range, train_losses, label='Training Loss', 
             color='#1f77b4', linestyle='-', linewidth=2, marker='.', markersize=6)
    
    # 验证损失
    ax1.plot(epochs_range, val_losses, label='Validation Loss', 
             color='#ff7f0e', linestyle='--', linewidth=2, marker='x', markersize=6)
    
    ax1.legend(loc='upper right', fontsize='medium')
    ax1.tick_params(axis='y', labelsize=10)
    
    # 强制X轴使用整数刻度
    ax1.xaxis.set_major_locator(MaxNLocator(integer=True))
    
    # --- 绘制准确率曲线 ---
    ax2.set_title(f'Model: {model_name} - Accuracy Curve', fontsize=14, weight='bold')
    ax2.set_xlabel('Epoch', fontsize=12)
    ax2.set_ylabel('Accuracy (%)', fontsize=12)
    ax2.grid(True, linestyle=':', linewidth=0.6, alpha=0.7)
    
    # 训练准确率
    ax2.plot(epochs_range, train_accs_percent, label='Training Accuracy', 
             color='#2ca02c', linestyle='-', linewidth=2, marker='.', markersize=6)
    
    # 验证准确率
    ax2.plot(epochs_range, val_accs_percent, label='Validation Accuracy', 
             color='#d62728', linestyle='--', linewidth=2, marker='x', markersize=6)
    
    # 找到最佳验证准确率及其对应的epoch
    best_val_acc_idx = np.argmax(val_accs_percent)
    best_val_acc = val_accs_percent[best_val_acc_idx]
    best_epoch = best_val_acc_idx + 1
    
    # --- 突出显示最佳验证准确率点 ---
    ax2.scatter(best_epoch, best_val_acc, color='red', s=60, zorder=5,
               label=f'Best Validation Point (Epoch {best_epoch})',
               facecolors='none', edgecolors='red', linewidth=2)
    
    # 添加注释文本
    ax2.annotate(f'Best: {best_val_acc:.2f}%',
                xy=(best_epoch, best_val_acc),
                xytext=(best_epoch + 1, best_val_acc + 1),
                ha='left',
                fontsize=10,
                arrowprops=dict(facecolor='red', shrink=0.05, width=1, headwidth=4, alpha=0.7))
    
    # --- 调整图例和Y轴范围 ---
    handles, labels = ax2.get_legend_handles_labels()
    filtered_handles = [h for h, l in zip(handles, labels) if 'Best Validation Point' in l or 'Accuracy' in l]
    filtered_labels = [l for l in labels if 'Best Validation Point' in l or 'Accuracy' in l]
    ax2.legend(filtered_handles, filtered_labels, loc='lower right', fontsize='medium')
    
    # 设置Y轴范围
    all_acc_data = train_accs_percent + val_accs_percent
    if all_acc_data:
        min_acc = np.min(all_acc_data)
        max_acc = np.max(all_acc_data)
        y_bottom = max(0, min_acc - 5)
        y_top = min(105, max_acc + 5)
        ax2.set_ylim(bottom=y_bottom, top=y_top)
    else:
        ax2.set_ylim(bottom=0, top=105)
    
    # 强制X轴使用整数刻度
    ax2.xaxis.set_major_locator(MaxNLocator(integer=True))
    ax2.tick_params(axis='both', labelsize=10)
    
    # --- 保存和关闭 ---
    fig.tight_layout(pad=1.5)
    save_path = os.path.join(save_dir, f'{model_name}_metrics.png')
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"模型 {model_name} 的训练曲线图已保存至 {save_path}")
    plt.close(fig)


def compare_models(models_metrics, save_dir):
    """
    比较不同模型的性能
    
    Args:
        models_metrics: 字典，键为模型名称，值为包含准确率和损失的字典
        save_dir: 保存目录
    """
    # 找出最佳模型
    best_model = None
    best_acc = 0
    
    for model_name, metrics in models_metrics.items():
        # 将准确率转换为百分比显示
        val_accs_percent = [acc * 100 for acc in metrics['val_accs']]
        max_val_acc = max(val_accs_percent)
        
        # 记录最佳模型
        if max_val_acc > best_acc:
            best_acc = max_val_acc
            best_model = model_name
    
    # 创建比较图表
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10), sharex=True)
    fig.suptitle(f'Models Comparison - Best: {best_model} ({best_acc:.2f}%)', 
                fontsize=16, weight='bold', y=0.98)
    
    # 获取训练轮数
    max_epochs = 0
    for metrics in models_metrics.values():
        max_epochs = max(max_epochs, len(metrics['train_losses']))
    
    epochs_range = list(range(1, max_epochs + 1))
    
    # --- 绘制损失对比曲线 ---
    ax1.set_title('Loss Comparison', fontsize=14, weight='bold')
    ax1.set_ylabel('Loss (Cross Entropy)', fontsize=12)
    ax1.grid(True, linestyle=':', linewidth=0.6, alpha=0.7)
    
    for model_name, metrics in models_metrics.items():
        train_losses = metrics['train_losses']
        val_losses = metrics['val_losses']
        
        # 确保数据长度一致
        train_epochs = len(train_losses)
        val_epochs = len(val_losses)
        model_epochs = min(train_epochs, val_epochs)
        model_range = epochs_range[:model_epochs]
        
        # 绘制验证损失曲线（只显示验证损失以保持图表清晰）
        ax1.plot(model_range, val_losses[:model_epochs], 
                label=f'{model_name} Validation',
                linewidth=2, marker='x', markersize=5)
    
    ax1.legend(loc='upper right', fontsize='medium')
    ax1.tick_params(axis='y', labelsize=10)
    
    # 强制X轴使用整数刻度
    ax1.xaxis.set_major_locator(MaxNLocator(integer=True))
    
    # --- 绘制准确率对比曲线 ---
    ax2.set_title('Accuracy Comparison', fontsize=14, weight='bold')
    ax2.set_xlabel('Epoch', fontsize=12)
    ax2.set_ylabel('Accuracy (%)', fontsize=12)
    ax2.grid(True, linestyle=':', linewidth=0.6, alpha=0.7)
    
    best_points = {}  # 存储每个模型的最佳点
    
    for model_name, metrics in models_metrics.items():
        train_accs = [acc * 100 for acc in metrics['train_accs']]
        val_accs = [acc * 100 for acc in metrics['val_accs']]
        
        # 确保数据长度一致
        train_epochs = len(train_accs)
        val_epochs = len(val_accs)
        model_epochs = min(train_epochs, val_epochs)
        model_range = epochs_range[:model_epochs]
        
        # 绘制验证准确率曲线（只显示验证准确率以保持图表清晰）
        line, = ax2.plot(model_range, val_accs[:model_epochs], 
                        label=f'{model_name} Validation',
                        linewidth=2, marker='x', markersize=5)
        
        # 找到最佳验证准确率点
        if val_accs:
            best_idx = np.argmax(val_accs[:model_epochs])
            best_acc = val_accs[best_idx]
            best_epoch = best_idx + 1
            
            # 记录最佳点信息
            best_points[model_name] = {
                'epoch': best_epoch,
                'accuracy': best_acc,
                'color': line.get_color()
            }
    
    # 为每个模型标注最佳点
    for model_name, point_info in best_points.items():
        epoch = point_info['epoch']
        accuracy = point_info['accuracy']
        color = point_info['color']
        
        # 绘制最佳点
        ax2.scatter(epoch, accuracy, color=color, s=80, zorder=5,
                   facecolors='none', edgecolors=color, linewidth=2)
        
        # 添加注释
        ax2.annotate(f'{model_name}: {accuracy:.2f}%',
                    xy=(epoch, accuracy),
                    xytext=(epoch + 0.5, accuracy + 1),
                    ha='left',
                    fontsize=9,
                    arrowprops=dict(facecolor=color, shrink=0.05, width=1, headwidth=4, alpha=0.7))
    
    # 设置Y轴范围
    all_accs = []
    for metrics in models_metrics.values():
        all_accs.extend([acc * 100 for acc in metrics['val_accs']])
    
    if all_accs:
        min_acc = np.min(all_accs)
        max_acc = np.max(all_accs)
        y_bottom = max(0, min_acc - 5)
        y_top = min(105, max_acc + 5)
        ax2.set_ylim(bottom=y_bottom, top=y_top)
    else:
        ax2.set_ylim(bottom=0, top=105)
    
    # 强制X轴使用整数刻度
    ax2.xaxis.set_major_locator(MaxNLocator(integer=True))
    ax2.legend(loc='lower right', fontsize='medium')
    ax2.tick_params(axis='both', labelsize=10)
    
    # --- 保存和关闭 ---
    fig.tight_layout(rect=[0, 0, 1, 0.95])  # 为顶部标题留出空间
    save_path = os.path.join(save_dir, 'models_comparison.png')
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"模型比较图表已保存至 {save_path}")
    plt.close(fig)
    
    # 打印最终准确率对比
    print("\n各模型最终验证准确率:")
    for model_name, metrics in models_metrics.items():
        print(f"{model_name}: {metrics['val_accs'][-1]*100:.2f}%")
    
    # 打印最佳模型信息
    print(f"\n最佳模型: {best_model}, 最高验证准确率: {best_acc:.2f}%")


def save_metrics(metrics, filename):
    """
    保存训练指标到文件
    
    Args:
        metrics: 包含训练指标的字典
        filename: 保存路径
    """
    torch.save(metrics, filename)
    print(f"保存训练指标: {filename}")


def save_model(model, model_name, save_dir):
    """
    保存完整模型（而非仅状态字典）
    
    Args:
        model: 模型
        model_name: 模型名称
        save_dir: 保存目录
    """
    save_path = os.path.join(save_dir, f"{model_name}_full_model.pth")
    torch.save(model, save_path)
    print(f"保存完整模型: {save_path}") 
import os
import torch
import multiprocessing

# 数据路径配置
DATA_ROOT = 'dataSets/rocks_augmented'
TRAIN_DIR = os.path.join(DATA_ROOT, 'train')
TEST_DIR = os.path.join(DATA_ROOT, 'test')

# 模型配置
MODEL_NAMES = ['resnet18', 'resnet34', 'resnet50', 'resnet101', 'vgg16', 'densenet121', 'mobilenetv2', 'efficientnetb0', 'efficientnetb1', 'efficientnetb2', 'efficientnetb3', 'efficientnetb4', 'efficientnetb5', 'inceptionv3', 'googlenet', 'vit', 'squeezenet', 'shufflenetv2', 'rshfnet', 'fshnet']
ATTENTION_TYPES = ['cbam', 'se', 'eca', 'spatial', 'channel', 'none']  # 支持的注意力机制类型
DEFAULT_ATTENTION = 'cbam'  # 默认使用CBAM注意力机制
TRAIN_MULTIPLE_MODELS = True  # 是否训练多个模型

# 训练参数
BATCH_SIZE = 16
NUM_EPOCHS = 100
LEARNING_RATE = 1e-4
WEIGHT_DECAY = 0.001
LABEL_SMOOTHING = 0.15
OPTIMIZER = 'AdamW'
LR_SCHEDULER = 'CosineAnnealingLR'
PCT_START = 0.3

# 设置NUM_WORKERS自动根据CPU核心数调整，最多使用8个worker
NUM_WORKERS = min(8, multiprocessing.cpu_count())

# 设备和性能优化参数
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'  # 优先使用CUDA (NVIDIA GPU)
CUDA_VISIBLE_DEVICES = '0'  # 指定使用的GPU设备，有多个GPU时可设为'0,1,2'
CUDNN_BENCHMARK = True  # 使用cudnn benchmark加速
CUDNN_DETERMINISTIC = False  # 禁用确定性模式以提高速度
MIXED_PRECISION = True  # 使用混合精度训练
PIN_MEMORY = True  # 数据加载器使用pin_memory
NON_BLOCKING = True  # 异步数据传输
PREFETCH_FACTOR = 2  # 数据预取因子

# 图像处理参数
IMG_SIZE = 384  # 调整为更大的输入尺寸
CROP_SIZE = 299  # 新增裁剪尺寸
MEAN = [0.485, 0.456, 0.406]
STD = [0.229, 0.224, 0.225]

# 数据增强参数
COLOR_JITTER = {
    'brightness': 0.4,
    'contrast': 0.4,
    'saturation': 0.4,
    'hue': 0.2
}
RANDOM_HORIZONTAL_FLIP_PROB = 0.7
RANDOM_VERTICAL_FLIP_PROB = 0.5
RANDOM_ROTATION_DEGREES = 45
RANDOM_ERASING_PROB = 0.3
RANDOM_ERASING_SCALE = (0.05, 0.2)

# 模型保存
# 注意：不再立即创建目录，而是在main.py中实际需要时创建
OUTPUT_DIR = 'output'  # 基础输出目录，具体子目录在实际运行时创建

# 日志参数
SAVE_FREQ = 5  # 每多少个epoch保存一次模型

# 根据设备设置优化参数
if DEVICE == 'cuda':
    # 启用cudnn benchmark以优化性能
    if CUDNN_BENCHMARK:
        torch.backends.cudnn.benchmark = True
    
    # 设置环境变量
    if CUDA_VISIBLE_DEVICES:
        os.environ['CUDA_VISIBLE_DEVICES'] = CUDA_VISIBLE_DEVICES 
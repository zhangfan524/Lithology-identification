import torch
import torch.nn as nn
import torchvision.models as models
from torch.nn import functional as F
import math


#====================== 注意力机制实现 ======================

class ChannelAttention(nn.Module):
    """CBAM中的通道注意力模块"""
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
           
        self.fc = nn.Sequential(
            nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False),
            nn.ReLU(),
            nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        out = avg_out + max_out
        return self.sigmoid(out)


class SpatialAttention(nn.Module):
    """CBAM中的空间注意力模块"""
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv1(x)
        return self.sigmoid(x)


class CBAMBlock(nn.Module):
    """CBAM注意力机制：结合通道和空间注意力"""
    def __init__(self, channel, ratio=16, kernel_size=7):
        super(CBAMBlock, self).__init__()
        self.channelattention = ChannelAttention(channel, ratio=ratio)
        self.spatialattention = SpatialAttention(kernel_size=kernel_size)

    def forward(self, x):
        x = x * self.channelattention(x)
        x = x * self.spatialattention(x)
        return x


class SEBlock(nn.Module):
    """SE (Squeeze-and-Excitation) 注意力机制"""
    def __init__(self, channel, ratio=16):
        super(SEBlock, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Sequential(
            nn.Linear(channel, channel // ratio, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(channel // ratio, channel, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c)
        y = self.fc(y).view(b, c, 1, 1)
        return x * y


class ECABlock(nn.Module):
    """ECA (Efficient Channel Attention) 注意力机制"""
    def __init__(self, channel, gamma=2, b=1):
        super(ECABlock, self).__init__()
        t = int(abs((math.log(channel, 2) + b) / gamma))
        k = t if t % 2 else t + 1
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=k, padding=(k - 1) // 2, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        b, c, _, _ = x.size()
        y = self.avg_pool(x).view(b, c, 1)
        y = self.conv(y.transpose(-1, -2)).transpose(-1, -2)
        y = self.sigmoid(y).view(b, c, 1, 1)
        return x * y


class OnlySpatialAttention(nn.Module):
    """只使用空间注意力的模块"""
    def __init__(self, kernel_size=7):
        super(OnlySpatialAttention, self).__init__()
        self.spatial = SpatialAttention(kernel_size=kernel_size)

    def forward(self, x):
        return x * self.spatial(x)


class OnlyChannelAttention(nn.Module):
    """只使用通道注意力的模块"""
    def __init__(self, channel, ratio=16):
        super(OnlyChannelAttention, self).__init__()
        self.channel = ChannelAttention(channel, ratio=ratio)

    def forward(self, x):
        return x * self.channel(x)


#====================== 模型实现 ======================

class ResNet18WithAttention(nn.Module):
    def __init__(self, num_classes, attention_type='cbam'):
        super(ResNet18WithAttention, self).__init__()
        model = models.resnet18(pretrained=True)
        self.backbone = nn.Sequential(*list(model.children())[:-2])  # 去除平均池化和全连接层
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(512, num_classes)
        
        # 注意力机制类型
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(512)
        elif attention_type == 'se':
            self.attention = SEBlock(512)
        elif attention_type == 'eca':
            self.attention = ECABlock(512)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(512)
        else:  # 'none' 或其他，不使用注意力机制
            self.attention = None

    def forward(self, x):
        x = self.backbone(x)
        if self.attention is not None:
            x = self.attention(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        return x


class ResNet34WithAttention(nn.Module):
    def __init__(self, num_classes, attention_type='cbam'):
        super(ResNet34WithAttention, self).__init__()
        model = models.resnet34(pretrained=True)
        self.backbone = nn.Sequential(*list(model.children())[:-2])
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(512, num_classes)
        
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(512)
        elif attention_type == 'se':
            self.attention = SEBlock(512)
        elif attention_type == 'eca':
            self.attention = ECABlock(512)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(512)
        else:
            self.attention = None

    def forward(self, x):
        x = self.backbone(x)
        if self.attention is not None:
            x = self.attention(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        return x


class ResNet50WithAttention(nn.Module):
    def __init__(self, num_classes, attention_type='cbam'):
        super(ResNet50WithAttention, self).__init__()
        model = models.resnet50(pretrained=True)
        self.backbone = nn.Sequential(*list(model.children())[:-2])
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(2048, num_classes)
        
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(2048)
        elif attention_type == 'se':
            self.attention = SEBlock(2048)
        elif attention_type == 'eca':
            self.attention = ECABlock(2048)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(2048)
        else:
            self.attention = None

    def forward(self, x):
        x = self.backbone(x)
        if self.attention is not None:
            x = self.attention(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        return x


class ResNet101WithAttention(nn.Module):
    def __init__(self, num_classes, attention_type='cbam'):
        super(ResNet101WithAttention, self).__init__()
        model = models.resnet101(pretrained=True)
        self.backbone = nn.Sequential(*list(model.children())[:-2])
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(2048, num_classes)
        
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(2048)
        elif attention_type == 'se':
            self.attention = SEBlock(2048)
        elif attention_type == 'eca':
            self.attention = ECABlock(2048)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(2048)
        else:
            self.attention = None

    def forward(self, x):
        x = self.backbone(x)
        if self.attention is not None:
            x = self.attention(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        return x


class SqueezeNetWithAttention(nn.Module):
    def __init__(self, num_classes, attention_type='cbam'):
        super(SqueezeNetWithAttention, self).__init__()
        model = models.squeezenet1_1(pretrained=True)
        self.backbone = model.features
        
        # 注意力机制类型
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(512)
        elif attention_type == 'se':
            self.attention = SEBlock(512)
        elif attention_type == 'eca':
            self.attention = ECABlock(512)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(512)
        else:  # 'none' 或其他，不使用注意力机制
            self.attention = None
            
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(512, num_classes)
        )

    def forward(self, x):
        x = self.backbone(x)
        if self.attention is not None:
            x = self.attention(x)
        x = self.classifier(x)
        return x


class ShuffleNetV2WithAttention(nn.Module):
    def __init__(self, num_classes, attention_type='cbam'):
        super(ShuffleNetV2WithAttention, self).__init__()
        model = models.shufflenet_v2_x1_0(pretrained=True)
        self.backbone = model.conv1
        self.maxpool = model.maxpool
        self.stage2 = model.stage2
        self.stage3 = model.stage3
        self.stage4 = model.stage4
        self.conv5 = model.conv5
        
        # 注意力机制类型
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(1024)
        elif attention_type == 'se':
            self.attention = SEBlock(1024)
        elif attention_type == 'eca':
            self.attention = ECABlock(1024)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(1024)
        else:  # 'none' 或其他，不使用注意力机制
            self.attention = None
            
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(1024, num_classes)
        )

    def forward(self, x):
        x = self.backbone(x)
        x = self.maxpool(x)
        x = self.stage2(x)
        x = self.stage3(x)
        x = self.stage4(x)
        x = self.conv5(x)
        if self.attention is not None:
            x = self.attention(x)
        x = self.classifier(x)
        return x


class VGG16WithAttention(nn.Module):
    def __init__(self, num_classes, attention_type='cbam'):
        super(VGG16WithAttention, self).__init__()
        model = models.vgg16(pretrained=True)
        self.backbone = nn.Sequential(*list(model.features.children()))
        
        # 注意力机制类型
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(512)
        elif attention_type == 'se':
            self.attention = SEBlock(512)
        elif attention_type == 'eca':
            self.attention = ECABlock(512)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(512)
        else:
            self.attention = None
            
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(512, num_classes)
        )

    def forward(self, x):
        x = self.backbone(x)
        if self.attention is not None:
            x = self.attention(x)
        x = self.classifier(x)
        return x


class DenseNet121WithAttention(nn.Module):
    def __init__(self, num_classes, attention_type='cbam'):
        super(DenseNet121WithAttention, self).__init__()
        model = models.densenet121(pretrained=True)
        self.backbone = model.features
        
        # 注意力机制类型
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(1024)
        elif attention_type == 'se':
            self.attention = SEBlock(1024)
        elif attention_type == 'eca':
            self.attention = ECABlock(1024)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(1024)
        else:
            self.attention = None
            
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(1024, num_classes)
        )

    def forward(self, x):
        x = self.backbone(x)
        if self.attention is not None:
            x = self.attention(x)
        x = self.classifier(x)
        return x


class MobileNetV2WithAttention(nn.Module):
    def __init__(self, num_classes, attention_type='cbam'):
        super(MobileNetV2WithAttention, self).__init__()
        model = models.mobilenet_v2(pretrained=True)
        self.backbone = model.features
        
        # 注意力机制类型
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(1280)
        elif attention_type == 'se':
            self.attention = SEBlock(1280)
        elif attention_type == 'eca':
            self.attention = ECABlock(1280)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(1280)
        else:
            self.attention = None
            
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(1280, num_classes)
        )

    def forward(self, x):
        x = self.backbone(x)
        if self.attention is not None:
            x = self.attention(x)
        x = self.classifier(x)
        return x


class EfficientNetB0WithAttention(nn.Module):
    def __init__(self, num_classes, attention_type='cbam'):
        super(EfficientNetB0WithAttention, self).__init__()
        model = models.efficientnet_b0(pretrained=True)
        self.backbone = model.features
        
        # 注意力机制类型
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(1280)
        elif attention_type == 'se':
            self.attention = SEBlock(1280)
        elif attention_type == 'eca':
            self.attention = ECABlock(1280)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(1280)
        else:
            self.attention = None
            
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(1280, num_classes)
        )

    def forward(self, x):
        x = self.backbone(x)
        if self.attention is not None:
            x = self.attention(x)
        x = self.classifier(x)
        return x


class InceptionV3WithAttention(nn.Module):
    def __init__(self, num_classes, attention_type='cbam'):
        super(InceptionV3WithAttention, self).__init__()
        model = models.inception_v3(pretrained=True)
        # InceptionV3的特征提取部分，去除分类器
        self.backbone = nn.Sequential(
            model.Conv2d_1a_3x3,
            model.Conv2d_2a_3x3,
            model.Conv2d_2b_3x3,
            nn.MaxPool2d(kernel_size=3, stride=2),
            model.Conv2d_3b_1x1,
            model.Conv2d_4a_3x3,
            nn.MaxPool2d(kernel_size=3, stride=2),
            model.Mixed_5b,
            model.Mixed_5c,
            model.Mixed_5d,
            model.Mixed_6a,
            model.Mixed_6b,
            model.Mixed_6c,
            model.Mixed_6d,
            model.Mixed_6e,
            model.Mixed_7a,
            model.Mixed_7b,
            model.Mixed_7c,
        )
        
        # 注意力机制类型
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(2048)
        elif attention_type == 'se':
            self.attention = SEBlock(2048)
        elif attention_type == 'eca':
            self.attention = ECABlock(2048)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(2048)
        else:
            self.attention = None
            
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(2048, num_classes)
        )

    def forward(self, x):
        x = self.backbone(x)
        if self.attention is not None:
            x = self.attention(x)
        x = self.classifier(x)
        return x


class VisionTransformerWithAttention(nn.Module):
    def __init__(self, num_classes, attention_type='cbam'):
        super(VisionTransformerWithAttention, self).__init__()
        model = models.vit_b_16(pretrained=True)
        self.backbone = model.encoder
        self.cls_token = model.cls_token
        self.pos_embedding = model.pos_embedding
        self.patch_embedding = model.patch_embedding
        
        # 注意力机制类型 - ViT使用transformer自带的注意力，这里仅在最后特征上添加额外注意力
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(768)
        elif attention_type == 'se':
            self.attention = SEBlock(768)
        elif attention_type == 'eca':
            self.attention = ECABlock(768)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(768)
        else:
            self.attention = None
            
        self.fc = nn.Linear(768, num_classes)

    def forward(self, x):
        x = self.patch_embedding(x)
        batch_size = x.shape[0]
        cls_tokens = self.cls_token.expand(batch_size, -1, -1)
        x = torch.cat((cls_tokens, x), dim=1)
        x = x + self.pos_embedding
        x = self.backbone(x)
        
        # 获取cls token的输出
        x = x[:, 0]
        x = x.unsqueeze(-1).unsqueeze(-1)  # 添加空间维度用于注意力
        
        if self.attention is not None:
            x = self.attention(x)
        
        x = torch.flatten(x, 1)
        x = self.fc(x)
        return x


class EfficientNetB1WithAttention(nn.Module):
    def __init__(self, num_classes, attention_type='cbam'):
        super(EfficientNetB1WithAttention, self).__init__()
        model = models.efficientnet_b1(pretrained=True)
        self.backbone = model.features
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(1280)
        elif attention_type == 'se':
            self.attention = SEBlock(1280)
        elif attention_type == 'eca':
            self.attention = ECABlock(1280)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(1280)
        else:
            self.attention = None
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(1280, num_classes)
        )

    def forward(self, x):
        x = self.backbone(x)
        if self.attention is not None:
            x = self.attention(x)
        x = self.classifier(x)
        return x


class EfficientNetB2WithAttention(nn.Module):
    def __init__(self, num_classes, attention_type='cbam'):
        super(EfficientNetB2WithAttention, self).__init__()
        model = models.efficientnet_b2(pretrained=True)
        self.backbone = model.features
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(1408)
        elif attention_type == 'se':
            self.attention = SEBlock(1408)
        elif attention_type == 'eca':
            self.attention = ECABlock(1408)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(1408)
        else:
            self.attention = None
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(1408, num_classes)
        )

    def forward(self, x):
        x = self.backbone(x)
        if self.attention is not None:
            x = self.attention(x)
        x = self.classifier(x)
        return x


class EfficientNetB3WithAttention(nn.Module):
    def __init__(self, num_classes, attention_type='cbam'):
        super(EfficientNetB3WithAttention, self).__init__()
        model = models.efficientnet_b3(pretrained=True)
        self.backbone = model.features
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(1536)
        elif attention_type == 'se':
            self.attention = SEBlock(1536)
        elif attention_type == 'eca':
            self.attention = ECABlock(1536)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(1536)
        else:
            self.attention = None
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(1536, num_classes)
        )

    def forward(self, x):
        x = self.backbone(x)
        if self.attention is not None:
            x = self.attention(x)
        x = self.classifier(x)
        return x


class EfficientNetB4WithAttention(nn.Module):
    def __init__(self, num_classes, attention_type='cbam'):
        super(EfficientNetB4WithAttention, self).__init__()
        model = models.efficientnet_b4(pretrained=True)
        self.backbone = model.features
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(1792)
        elif attention_type == 'se':
            self.attention = SEBlock(1792)
        elif attention_type == 'eca':
            self.attention = ECABlock(1792)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(1792)
        else:
            self.attention = None
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(1792, num_classes)
        )

    def forward(self, x):
        x = self.backbone(x)
        if self.attention is not None:
            x = self.attention(x)
        x = self.classifier(x)
        return x


class EfficientNetB5WithAttention(nn.Module):
    def __init__(self, num_classes, attention_type='cbam'):
        super(EfficientNetB5WithAttention, self).__init__()
        model = models.efficientnet_b5(pretrained=True)
        self.backbone = model.features
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(2048)
        elif attention_type == 'se':
            self.attention = SEBlock(2048)
        elif attention_type == 'eca':
            self.attention = ECABlock(2048)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(2048)
        else:
            self.attention = None
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(2048, num_classes)
        )

    def forward(self, x):
        x = self.backbone(x)
        if self.attention is not None:
            x = self.attention(x)
        x = self.classifier(x)
        return x


class GoogLeNetWithAttention(nn.Module):
    def __init__(self, num_classes, attention_type='cbam'):
        super(GoogLeNetWithAttention, self).__init__()
        model = models.googlenet(pretrained=True)
        self.backbone = nn.Sequential(
            model.conv1,
            model.maxpool1,
            model.conv2,
            model.conv3,
            model.maxpool2,
            model.inception3a,
            model.inception3b,
            model.maxpool3,
            model.inception4a,
            model.inception4b,
            model.inception4c,
            model.inception4d,
            model.inception4e,
            model.maxpool4,
            model.inception5a,
            model.inception5b,
        )
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(1024)
        elif attention_type == 'se':
            self.attention = SEBlock(1024)
        elif attention_type == 'eca':
            self.attention = ECABlock(1024)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(1024)
        else:
            self.attention = None
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(1024, num_classes)
        )

    def forward(self, x):
        x = self.backbone(x)
        if self.attention is not None:
            x = self.attention(x)
        x = self.classifier(x)
        return x


class MultiScaleFeatureFusion(nn.Module):
    """多尺度特征融合模块 (MSF) - 来自 RSHFNet 论文"""
    def __init__(self, in_channels):
        super(MultiScaleFeatureFusion, self).__init__()
        self.conv1x1 = nn.Conv2d(in_channels, in_channels, kernel_size=1, bias=False)
        self.conv3x3 = nn.Conv2d(in_channels, in_channels, kernel_size=3, padding=1, bias=False)
        self.conv5x5 = nn.Conv2d(in_channels, in_channels, kernel_size=5, padding=2, bias=False)
        self.conv7x7 = nn.Conv2d(in_channels, in_channels, kernel_size=7, padding=3, bias=False)
        self.bn = nn.BatchNorm2d(in_channels)
        self.relu = nn.ReLU(inplace=True)
        
    def forward(self, x):
        out1 = self.conv1x1(x)
        out3 = self.conv3x3(x)
        out5 = self.conv5x5(x)
        out7 = self.conv7x7(x)
        out = out1 + out3 + out5 + out7
        out = self.bn(out)
        out = self.relu(out)
        return out


class RSHFNet(nn.Module):
    """RSHFNet - 基于 ShuffleNetV2 + CBAM + 多尺度特征融合 (MSF)
    参考论文: Rock image lithology recognition method based on lightweight convolutional neural network (2024)
    """
    def __init__(self, num_classes, attention_type='cbam'):
        super(RSHFNet, self).__init__()
        model = models.shufflenet_v2_x1_0(pretrained=True)
        
        # 使用前三个stage提取特征
        self.backbone = nn.Sequential(
            model.conv1,
            model.maxpool,
            model.stage2,
            model.stage3,
        )
        
        # 第四个stage后添加注意力和多尺度融合
        self.stage4 = model.stage4
        self.conv5 = model.conv5
        
        # 多尺度特征融合模块
        self.msf = MultiScaleFeatureFusion(1024)
        
        # 注意力机制
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(1024)
        elif attention_type == 'se':
            self.attention = SEBlock(1024)
        elif attention_type == 'eca':
            self.attention = ECABlock(1024)
        elif attention_type == 'spatial':
            self.attention = OnlySpatialAttention()
        elif attention_type == 'channel':
            self.attention = OnlyChannelAttention(1024)
        else:
            self.attention = None
            
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(1024, num_classes)
        )

    def forward(self, x):
        x = self.backbone(x)
        x = self.stage4(x)
        x = self.conv5(x)
        x = self.msf(x)  # 多尺度特征融合
        if self.attention is not None:
            x = self.attention(x)
        x = self.classifier(x)
        return x


class FSHNet(nn.Module):
    """FSHNet - 基于 VGG16 + EfficientNetV2B0 混合模型
    参考论文: Classification of Thin-Section Rock Images Using a Combined CNN and SVM Approach (2025)
    """
    def __init__(self, num_classes, attention_type='cbam'):
        super(FSHNet, self).__init__()
        
        # VGG16 特征提取
        vgg16 = models.vgg16(pretrained=True)
        self.vgg_backbone = nn.Sequential(*list(vgg16.features.children())[:-1])
        
        # EfficientNetV2B0 特征提取
        effnet = models.efficientnet_v2_s(pretrained=True)
        self.effnet_backbone = effnet.features
        
        # 注意力机制（应用于融合后的特征）
        self.attention_type = attention_type
        if attention_type == 'cbam':
            self.attention = CBAMBlock(1024)
        elif attention_type == 'se':
            self.attention = SEBlock(1024)
        elif attention_type == 'eca':
            self.attention = ECABlock(1024)
        else:
            self.attention = None
            
        # 特征融合和分类器
        self.fusion_conv = nn.Conv2d(512 + 1280, 1024, kernel_size=1, bias=False)
        self.bn = nn.BatchNorm2d(1024)
        self.relu = nn.ReLU(inplace=True)
        
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d((1, 1)),
            nn.Flatten(),
            nn.Linear(1024, num_classes)
        )

    def forward(self, x):
        # VGG16 特征
        vgg_feat = self.vgg_backbone(x)
        
        # EfficientNetV2 特征
        eff_feat = self.effnet_backbone(x)
        
        # 调整特征图大小以匹配
        vgg_feat = nn.functional.interpolate(vgg_feat, size=eff_feat.size()[2:], mode='bilinear', align_corners=False)
        
        # 特征融合
        fused = torch.cat([vgg_feat, eff_feat], dim=1)
        fused = self.fusion_conv(fused)
        fused = self.bn(fused)
        fused = self.relu(fused)
        
        # 注意力机制
        if self.attention is not None:
            fused = self.attention(fused)
        
        # 分类
        x = self.classifier(fused)
        return x


def get_model(model_name, num_classes, attention_type='cbam'):
    """
    获取指定的模型
    
    Args:
        model_name: 模型名称，支持多种模型
        num_classes: 类别数
        attention_type: 注意力机制类型，支持 'cbam', 'se', 'eca', 'spatial', 'channel', 'none'
        
    Returns:
        model: 模型实例
    """
    if model_name == 'resnet18':
        return ResNet18WithAttention(num_classes, attention_type)
    elif model_name == 'resnet34':
        return ResNet34WithAttention(num_classes, attention_type)
    elif model_name == 'resnet50':
        return ResNet50WithAttention(num_classes, attention_type)
    elif model_name == 'resnet101':
        return ResNet101WithAttention(num_classes, attention_type)
    elif model_name == 'vgg16':
        return VGG16WithAttention(num_classes, attention_type)
    elif model_name == 'densenet121':
        return DenseNet121WithAttention(num_classes, attention_type)
    elif model_name == 'mobilenetv2':
        return MobileNetV2WithAttention(num_classes, attention_type)
    elif model_name == 'efficientnetb0':
        return EfficientNetB0WithAttention(num_classes, attention_type)
    elif model_name == 'efficientnetb1':
        return EfficientNetB1WithAttention(num_classes, attention_type)
    elif model_name == 'efficientnetb2':
        return EfficientNetB2WithAttention(num_classes, attention_type)
    elif model_name == 'efficientnetb3':
        return EfficientNetB3WithAttention(num_classes, attention_type)
    elif model_name == 'efficientnetb4':
        return EfficientNetB4WithAttention(num_classes, attention_type)
    elif model_name == 'efficientnetb5':
        return EfficientNetB5WithAttention(num_classes, attention_type)
    elif model_name == 'inceptionv3':
        return InceptionV3WithAttention(num_classes, attention_type)
    elif model_name == 'googlenet':
        return GoogLeNetWithAttention(num_classes, attention_type)
    elif model_name == 'vit':
        return VisionTransformerWithAttention(num_classes, attention_type)
    elif model_name == 'squeezenet':
        return SqueezeNetWithAttention(num_classes, attention_type)
    elif model_name == 'shufflenetv2':
        return ShuffleNetV2WithAttention(num_classes, attention_type)
    elif model_name == 'rshfnet':
        return RSHFNet(num_classes, attention_type)
    elif model_name == 'fshnet':
        return FSHNet(num_classes, attention_type)
    else:
        raise ValueError(f"不支持的模型: {model_name}") 
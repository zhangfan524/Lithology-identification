import os
import argparse
import torch
import shutil
from datetime import datetime

import config
from train import train_model
from utils import compare_models


def clean_empty_dirs(output_dir):
    """清理空的输出目录"""
    if not os.path.exists(output_dir):
        return
        
    for item in os.listdir(output_dir):
        dir_path = os.path.join(output_dir, item)
        if os.path.isdir(dir_path):
            # 检查目录是否为空或只包含空目录
            is_empty = True
            for root, dirs, files in os.walk(dir_path):
                if files:
                    is_empty = False
                    break
            
            if is_empty:
                shutil.rmtree(dir_path)
                print(f"已删除空目录: {dir_path}")


def main():
    """
    主函数，根据命令行参数训练和评估模型
    """
    parser = argparse.ArgumentParser(description='岩石图像分类')
    parser.add_argument('--model', type=str, default='resnet18', 
                        choices=['resnet18', 'resnet34', 'resnet50', 'resnet101', 'vgg16', 'densenet121', 'mobilenetv2', 
                                'efficientnetb0', 'efficientnetb1', 'efficientnetb2', 'efficientnetb3', 'efficientnetb4', 'efficientnetb5',
                                'inceptionv3', 'googlenet', 'vit', 'squeezenet', 'shufflenetv2', 'rshfnet', 'fshnet', 'all'],
                        help='模型名称')
    parser.add_argument('--attention', type=str, default=config.DEFAULT_ATTENTION,
                        choices=config.ATTENTION_TYPES,
                        help='注意力机制类型: cbam-CBAM注意力, se-SE注意力, eca-ECA注意力, spatial-空间注意力, channel-通道注意力, none-无注意力')
    parser.add_argument('--attention-ablation', action='store_true', 
                        help='进行注意力机制消融实验，将使用所有注意力类型训练同一模型')
    parser.add_argument('--epochs', type=int, default=None, help='训练轮数')
    parser.add_argument('--batch-size', type=int, default=None, help='批次大小')
    parser.add_argument('--lr', type=float, default=None, help='学习率')
    parser.add_argument('--clean', action='store_true', help='清理空的输出目录')
    
    args = parser.parse_args()
    
    # 先清理空目录
    if args.clean:
        clean_empty_dirs(config.OUTPUT_DIR)
        print("已完成空目录清理")
        return
    
    # 更新配置
    if args.epochs is not None:
        config.NUM_EPOCHS = args.epochs
        print(f"设置训练轮数: {config.NUM_EPOCHS}")
    
    if args.batch_size is not None:
        config.BATCH_SIZE = args.batch_size
        print(f"设置批次大小: {config.BATCH_SIZE}")
    
    if args.lr is not None:
        config.LEARNING_RATE = args.lr
        print(f"设置学习率: {config.LEARNING_RATE}")
    
    # 在实际开始训练前创建输出目录
    try:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        run_output_dir = os.path.join(config.OUTPUT_DIR, timestamp)
        os.makedirs(run_output_dir, exist_ok=True)
        
        # 保存当前配置
        with open(os.path.join(run_output_dir, 'config.txt'), 'w') as f:
            f.write(f"模型: {args.model}\n")
            f.write(f"注意力机制: {args.attention}\n")
            f.write(f"批次大小: {config.BATCH_SIZE}\n")
            f.write(f"训练轮数: {config.NUM_EPOCHS}\n")
            f.write(f"学习率: {config.LEARNING_RATE}\n")
            f.write(f"权重衰减: {config.WEIGHT_DECAY}\n")
            f.write(f"图像大小: {config.IMG_SIZE}\n")
        
        print(f"输出目录: {run_output_dir}")
        
        # 注意力机制消融实验
        if args.attention_ablation:
            print(f"\n进行注意力机制消融实验: 模型 {args.model}")
            models_metrics = {}
            
            for attention_type in config.ATTENTION_TYPES:
                model_with_attn_name = f"{args.model}_{attention_type}"
                print(f"\n训练模型: {args.model}, 注意力机制: {attention_type}")
                metrics = train_model(args.model, attention_type, run_output_dir)
                models_metrics[model_with_attn_name] = metrics
            
            # 比较所有注意力机制
            compare_models(models_metrics, run_output_dir)
            
        # 训练模型
        elif args.model == 'all':
            print("训练所有模型")
            models_metrics = {}
            
            for model_name in config.MODEL_NAMES:
                print(f"\n开始训练模型: {model_name}, 注意力机制: {args.attention}")
                metrics = train_model(model_name, args.attention, run_output_dir)
                models_metrics[model_name] = metrics
            
            # 比较所有模型
            compare_models(models_metrics, run_output_dir)
        else:
            print(f"\n开始训练模型: {args.model}, 注意力机制: {args.attention}")
            train_model(args.model, args.attention, run_output_dir)
    
    except Exception as e:
        print(f"训练过程中出错: {e}")
        # 发生错误时，检查输出目录是否为空，如果是则删除
        if 'run_output_dir' in locals():
            if os.path.exists(run_output_dir):
                if not os.listdir(run_output_dir):
                    os.rmdir(run_output_dir)
                    print(f"已删除空输出目录: {run_output_dir}")
        raise  # 重新抛出异常以显示详细错误信息


if __name__ == '__main__':
    main() 
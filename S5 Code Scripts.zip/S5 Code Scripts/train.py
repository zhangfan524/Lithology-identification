import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.optim.lr_scheduler import ReduceLROnPlateau, CosineAnnealingLR, OneCycleLR
from tqdm import tqdm
from sklearn.metrics import precision_score, recall_score, f1_score
import config
from models import get_model
from utils import get_data_loaders, save_checkpoint, plot_metrics, save_metrics
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from datetime import datetime

def train_one_epoch(model, train_loader, criterion, optimizer, device, scheduler=None, scaler=None):
    """
    训练模型一个epoch
    
    Args:
        model: 模型
        train_loader: 训练数据加载器
        criterion: 损失函数
        optimizer: 优化器
        device: 设备
        scheduler: 学习率调度器（如果是OneCycleLR，每个batch更新一次）
        scaler: 混合精度训练的梯度缩放器
        
    Returns:
        avg_loss: 平均损失
        accuracy: 准确率
    """
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0
    
    for inputs, targets in tqdm(train_loader, desc="训练"):
        inputs, targets = inputs.to(device, non_blocking=config.NON_BLOCKING), targets.to(device, non_blocking=config.NON_BLOCKING)
        
        # 梯度清零
        optimizer.zero_grad()
        
        # 混合精度训练
        if scaler is not None:
            with torch.cuda.amp.autocast():
                outputs = model(inputs)
                loss = criterion(outputs, targets)
            
            # 反向传播和优化（使用梯度缩放）
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
        else:
            # 标准训练
            outputs = model(inputs)
            loss = criterion(outputs, targets)
            loss.backward()
            optimizer.step()
        
        # 如果使用OneCycleLR，每个batch更新学习率
        if scheduler is not None and isinstance(scheduler, OneCycleLR):
            scheduler.step()
        
        # 统计
        running_loss += loss.item() * inputs.size(0)
        _, predicted = outputs.max(1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()
    
    avg_loss = running_loss / total
    accuracy = correct / total
    
    return avg_loss, accuracy


def validate(model, val_loader, criterion, device, scaler=None):
    """
    在验证集上评估模型
    
    Args:
        model: 模型
        val_loader: 验证数据加载器
        criterion: 损失函数
        device: 设备
        scaler: 混合精度训练的梯度缩放器
        
    Returns:
        avg_loss: 平均损失
        accuracy: 准确率
        recall: 召回率
        precision: 精确率
        f1: F1分数
    """
    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0
    
    all_targets = []
    all_preds = []
    with torch.no_grad():
        for inputs, targets in tqdm(val_loader, desc="验证"):
            inputs, targets = inputs.to(device, non_blocking=config.NON_BLOCKING), targets.to(device, non_blocking=config.NON_BLOCKING)
            
            # 前向传播（可选混合精度）
            if scaler is not None:
                with torch.cuda.amp.autocast():
                    outputs = model(inputs)
                    loss = criterion(outputs, targets)
            else:
                outputs = model(inputs)
                loss = criterion(outputs, targets)
            
            # 统计
            running_loss += loss.item() * inputs.size(0)
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()
            all_targets.extend(targets.cpu().numpy())
            all_preds.extend(predicted.cpu().numpy())
    
    avg_loss = running_loss / total
    accuracy = correct / total
    
    # 计算 recall、precision、f1（宏平均，适合多分类）
    recall = recall_score(all_targets, all_preds, average='macro', zero_division=0)
    precision = precision_score(all_targets, all_preds, average='macro', zero_division=0)
    f1 = f1_score(all_targets, all_preds, average='macro', zero_division=0)
    
    return avg_loss, accuracy, recall, precision, f1


def test_per_class(model, test_loader, criterion, device, class_names, scaler=None):
    """
    在测试集上评估模型并计算每个类别的损失
    
    Args:
        model: 模型
        test_loader: 测试数据加载器
        criterion: 损失函数
        device: 设备
        class_names: 类别名称列表
        scaler: 混合精度训练的梯度缩放器
        
    Returns:
        class_losses: 包含每个类别平均损失的字典
    """
    model.eval()
    class_losses = {name: 0.0 for name in class_names}
    class_counts = {name: 0 for name in class_names}
    
    criterion_none = nn.CrossEntropyLoss(reduction='none') # To get per-sample loss
    
    with torch.no_grad():
        for inputs, targets in tqdm(test_loader, desc="计算各类别损失"):
            inputs, targets = inputs.to(device, non_blocking=config.NON_BLOCKING), targets.to(device, non_blocking=config.NON_BLOCKING)
            
            if scaler is not None:
                with torch.cuda.amp.autocast():
                    outputs = model(inputs)
                    losses = criterion_none(outputs, targets)
            else:
                outputs = model(inputs)
                losses = criterion_none(outputs, targets)

            for i in range(len(targets)):
                class_idx = targets[i].item()
                class_name = class_names[class_idx]
                class_losses[class_name] += losses[i].item()
                class_counts[class_name] += 1

    avg_class_losses = {name: (loss / class_counts[name]) if class_counts[name] > 0 else 0.0 
                        for name, loss in class_losses.items()}

    return avg_class_losses


def save_best_test_losses(class_losses, model_name, output_dir):
    """
    保存每个类别在测试集上的最佳损失率到txt文件
    
    Args:
        class_losses: 包含每个类别损失的字典
        model_name: 模型名称
        output_dir: 输出目录
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = os.path.join(output_dir, f'best_test_losses_{model_name}_{timestamp}.txt')
    
    with open(log_path, 'w', encoding='utf-8') as f:
        f.write(f"模型在测试集上的各类别最佳损失率 - {model_name}\n")
        f.write("=" * 50 + "\n\n")
        
        for class_name, loss in class_losses.items():
            f.write(f"{class_name}: {loss:.4f}\n")
            
    print(f"各类别最佳测试损失已保存到：{log_path}")


def save_training_data(train_losses, train_accs, val_losses, val_accs, val_recalls, val_precisions, val_f1s, model_name, output_dir):
    """
    保存训练数据到txt文件，按类别分组展示
    
    Args:
        train_losses: 训练损失列表
        train_accs: 训练准确率列表
        val_losses: 验证损失列表
        val_accs: 验证准确率列表
        val_recalls: 验证召回率列表
        val_precisions: 验证精确率列表
        val_f1s: 验证F1分数列表
        model_name: 模型名称
        output_dir: 输出目录
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = os.path.join(output_dir, f'training_data_{model_name}_{timestamp}.txt')
    
    with open(log_path, 'w', encoding='utf-8') as f:
        f.write(f"模型训练数据记录 - {model_name}\n")
        f.write("=" * 50 + "\n\n")
        
        # 训练损失
        f.write("训练损失:\n")
        f.write("-" * 30 + "\n")
        for i, loss in enumerate(train_losses, 1):
            f.write(f"Epoch {i}: {loss:.4f}\n")
        f.write("\n")
        
        # 训练准确率
        f.write("训练准确率:\n")
        f.write("-" * 30 + "\n")
        for i, acc in enumerate(train_accs, 1):
            f.write(f"Epoch {i}: {acc*100:.2f}%\n")
        f.write("\n")
        
        # 验证损失
        f.write("验证损失:\n")
        f.write("-" * 30 + "\n")
        for i, loss in enumerate(val_losses, 1):
            f.write(f"Epoch {i}: {loss:.4f}\n")
        f.write("\n")
        
        # 验证准确率
        f.write("验证准确率:\n")
        f.write("-" * 30 + "\n")
        for i, acc in enumerate(val_accs, 1):
            f.write(f"Epoch {i}: {acc*100:.2f}%\n")
        f.write("\n")
        
        # 验证召回率
        f.write("验证召回率:\n")
        f.write("-" * 30 + "\n")
        for i, recall in enumerate(val_recalls, 1):
            f.write(f"Epoch {i}: {recall*100:.2f}%\n")
        f.write("\n")
        
        # 验证精确率
        f.write("验证精确率:\n")
        f.write("-" * 30 + "\n")
        for i, precision in enumerate(val_precisions, 1):
            f.write(f"Epoch {i}: {precision*100:.2f}%\n")
        f.write("\n")
        
        # 验证F1分数
        f.write("验证F1分数:\n")
        f.write("-" * 30 + "\n")
        for i, f1 in enumerate(val_f1s, 1):
            f.write(f"Epoch {i}: {f1*100:.2f}%\n")
        f.write("\n")
        
        # 最佳结果
        f.write("最佳结果:\n")
        f.write("-" * 30 + "\n")
        best_val_acc = max(val_accs)
        best_epoch = val_accs.index(best_val_acc) + 1
        f.write(f"最佳验证准确率: {best_val_acc*100:.2f}% (Epoch {best_epoch})\n")
        f.write(f"对应的训练准确率: {train_accs[best_epoch-1]*100:.2f}%\n")
        f.write(f"对应的训练损失: {train_losses[best_epoch-1]:.4f}\n")
        f.write(f"对应的验证损失: {val_losses[best_epoch-1]:.4f}\n")
        f.write(f"对应的验证召回率: {val_recalls[best_epoch-1]*100:.2f}%\n")
        f.write(f"对应的验证精确率: {val_precisions[best_epoch-1]*100:.2f}%\n")
        f.write(f"对应的验证F1分数: {val_f1s[best_epoch-1]*100:.2f}%\n")
    
    print(f"训练数据已保存到：{log_path}")


def train_model(model_name, attention_type=config.DEFAULT_ATTENTION, output_dir=None):
    """
    训练和评估模型
    
    Args:
        model_name: 模型名称
        attention_type: 注意力机制类型
        output_dir: 输出目录，如果为None则创建新目录
        
    Returns:
        metrics: 包含训练和验证损失、准确率的字典
    """
    # 设置设备
    if config.DEVICE == 'cuda' and torch.cuda.is_available():
        device = torch.device('cuda')
        print(f"使用CUDA设备: {torch.cuda.get_device_name(0)}")
    elif config.DEVICE == 'dml':
        try:
            device = torch_directml.device()
            print(f"使用DirectML设备: {device}")
        except (NameError, ImportError):
            print("警告: torch_directml未正确导入，回退到CPU")
            device = torch.device('cpu')
    else:
        device = torch.device('cpu')
        print("使用CPU训练")
    
    # 创建新的输出目录
    if output_dir is None:
        output_dir = config.OUTPUT_DIR
        os.makedirs(output_dir, exist_ok=True)
        models_dir = os.path.join(output_dir, 'models')
        plots_dir = os.path.join(output_dir, 'plots')
        os.makedirs(models_dir, exist_ok=True)
        os.makedirs(plots_dir, exist_ok=True)
    else:
        models_dir = os.path.join(output_dir, 'models')
        plots_dir = os.path.join(output_dir, 'plots')
        os.makedirs(models_dir, exist_ok=True)
        os.makedirs(plots_dir, exist_ok=True)
    
    # 获取数据加载器
    train_loader, test_loader, num_classes = get_data_loaders()
    print(f"类别数量: {num_classes}")
    print(f"训练样本数: {len(train_loader.dataset)}")
    print(f"测试样本数: {len(test_loader.dataset)}")
    
    # 创建模型
    model = get_model(model_name, num_classes, attention_type)
    model = model.to(device)
    
    # 根据配置选择优化器
    if hasattr(config, 'OPTIMIZER'):
        if config.OPTIMIZER.lower() == 'adamw':
            optimizer = optim.AdamW(
                model.parameters(), 
                lr=config.LEARNING_RATE, 
                weight_decay=config.WEIGHT_DECAY
            )
        elif config.OPTIMIZER.lower() == 'adam':
            optimizer = optim.Adam(
                model.parameters(), 
                lr=config.LEARNING_RATE, 
                weight_decay=config.WEIGHT_DECAY
            )
        elif config.OPTIMIZER.lower() == 'sgd':
            optimizer = optim.SGD(
                model.parameters(), 
                lr=config.LEARNING_RATE, 
                momentum=0.9, 
                weight_decay=config.WEIGHT_DECAY
            )
        else:
            optimizer = optim.Adam(
                model.parameters(), 
                lr=config.LEARNING_RATE, 
                weight_decay=config.WEIGHT_DECAY
            )
    else:
        optimizer = optim.Adam(
            model.parameters(), 
            lr=config.LEARNING_RATE, 
            weight_decay=config.WEIGHT_DECAY
        )
    
    # 根据配置选择学习率调度器
    if hasattr(config, 'LR_SCHEDULER'):
        if config.LR_SCHEDULER.lower() == 'cosineannealinglr':
            scheduler = CosineAnnealingLR(
                optimizer, 
                T_max=config.NUM_EPOCHS
            )
        elif config.LR_SCHEDULER.lower() == 'onecyclelr':
            scheduler = OneCycleLR(
                optimizer,
                max_lr=config.LEARNING_RATE,
                steps_per_epoch=len(train_loader),
                epochs=config.NUM_EPOCHS,
                pct_start=getattr(config, 'PCT_START', 0.3)
            )
        elif config.LR_SCHEDULER.lower() == 'reducelronplateau':
            scheduler = ReduceLROnPlateau(
                optimizer, 
                mode='min', 
                factor=0.1, 
                patience=5, 
                verbose=True
            )
        else:
            scheduler = None
    else:
        scheduler = None
    
    # 使用带标签平滑的交叉熵损失
    label_smoothing = getattr(config, 'LABEL_SMOOTHING', 0.0)
    criterion = nn.CrossEntropyLoss(label_smoothing=label_smoothing)
    
    # 是否使用混合精度训练
    scaler = None
    if hasattr(config, 'MIXED_PRECISION') and config.MIXED_PRECISION and device.type == 'cuda':
        scaler = torch.cuda.amp.GradScaler()
        print("启用混合精度训练")
    
    # 训练准备
    best_val_acc = 0.0
    train_losses, train_accs = [], []
    val_losses, val_accs, val_recalls, val_precisions, val_f1s = [], [], [], [], []
    
    # 记录模型配置
    model_save_name = f"{model_name}_{attention_type}"
    model_save_path = os.path.join(models_dir, f"{model_save_name}_best.pth")
    
    # 开始训练
    print(f"开始训练: {model_save_name}")
    for epoch in range(config.NUM_EPOCHS):
        print(f"\nEpoch {epoch+1}/{config.NUM_EPOCHS}")
        
        # 训练一个epoch
        train_loss, train_acc = train_one_epoch(
            model, 
            train_loader, 
            criterion, 
            optimizer, 
            device,
            scheduler if isinstance(scheduler, OneCycleLR) else None,
            scaler
        )
        train_losses.append(train_loss)
        train_accs.append(train_acc)
        
        # 在验证集上评估
        val_loss, val_acc, val_recall, val_precision, val_f1 = validate(model, test_loader, criterion, device, scaler)
        val_losses.append(val_loss)
        val_accs.append(val_acc)
        val_recalls.append(val_recall)
        val_precisions.append(val_precision)
        val_f1s.append(val_f1)
        
        # 更新学习率（对于不是OneCycleLR的调度器）
        if scheduler is not None and not isinstance(scheduler, OneCycleLR):
            if isinstance(scheduler, ReduceLROnPlateau):
                scheduler.step(val_loss)
            else:
                scheduler.step()
        
        # 打印进度 - 将准确率转换为百分比
        print(f"训练损失: {train_loss:.4f}, 训练准确率: {train_acc*100:.2f}%")
        print(f"验证损失: {val_loss:.4f}, 验证准确率: {val_acc*100:.2f}%, 验证Recall: {val_recall:.4f}, 验证Precision: {val_precision:.4f}")
        
        # 只保存验证集上效果最好的模型
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            save_checkpoint({
                'epoch': epoch + 1,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'best_val_acc': best_val_acc,
                'attention_type': attention_type
            }, model_save_path)
            print(f"保存最佳模型，验证准确率: {best_val_acc*100:.2f}%")
        
        # 定期保存模型（如果配置了）
        if hasattr(config, 'SAVE_FREQ') and config.SAVE_FREQ > 0 and (epoch + 1) % config.SAVE_FREQ == 0:
            checkpoint_path = os.path.join(models_dir, f"{model_save_name}_epoch{epoch+1}.pth")
            save_checkpoint({
                'epoch': epoch + 1,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'val_acc': val_acc,
                'attention_type': attention_type
            }, checkpoint_path)
            print(f"保存第 {epoch+1} 个epoch的模型")
    
    # 绘制训练过程图表
    plot_metrics(train_losses, train_accs, val_losses, val_accs, model_save_name, plots_dir)
    
    # 保存训练指标
    metrics = {
        'train_losses': train_losses,
        'train_accs': train_accs,
        'val_losses': val_losses,
        'val_accs': val_accs,
        'val_recalls': val_recalls,
        'val_precisions': val_precisions,
        'val_f1s': val_f1s,
        'best_val_acc': best_val_acc
    }
    metrics_path = os.path.join(plots_dir, f"{model_save_name}_metrics.pth")
    save_metrics(metrics, metrics_path)
    
    # 在绘制混淆矩阵之前添加保存训练数据的调用
    save_training_data(train_losses, train_accs, val_losses, val_accs, val_recalls, val_precisions, val_f1s, model_save_name, output_dir)
    
    # ========== 这里插入混淆矩阵代码 ==========

    # 用最佳模型在测试集上收集标签
    model.load_state_dict(torch.load(model_save_path)['model_state_dict'])
    model.eval()
    y_true = []
    y_pred = []

    with torch.no_grad():
        for inputs, targets in test_loader:
            inputs = inputs.to(device, non_blocking=config.NON_BLOCKING)
            targets = targets.to(device, non_blocking=config.NON_BLOCKING)
            outputs = model(inputs)
            _, predicted = outputs.max(1)
            y_true.extend(targets.cpu().numpy())
            y_pred.extend(predicted.cpu().numpy())

    class_names = train_loader.dataset.classes

    # 3. 计算混淆矩阵和每类准确率
    cm = confusion_matrix(y_true, y_pred)
    num_classes = len(class_names)
    recall_per_class = cm.diagonal() / cm.sum(axis=1)
    recall_per_class_percent = recall_per_class * 100
    cm_with_acc = np.concatenate([cm, recall_per_class_percent.reshape(-1, 1)], axis=1)
    class_names_with_acc = class_names + ['acc(%)']

    # 4. 构造每个格子的显示内容（数量+百分比）
    cm_sum = cm.sum(axis=1, keepdims=True)
    cm_perc = np.divide(cm, cm_sum, where=cm_sum!=0) * 100
    labels = np.empty_like(cm).astype(str)
    for i in range(num_classes):
        for j in range(num_classes):
            labels[i, j] = f"{cm[i, j]}\n{cm_perc[i, j]:.2f}%"
    acc_labels = np.array([f"{recall_per_class_percent[i]:.2f}%" for i in range(num_classes)]).reshape(-1, 1)
    labels_with_acc = np.concatenate([labels, acc_labels], axis=1)

    # 5. 绘制并保存
    plt.figure(figsize=(10, 8))
    sns.heatmap(
        cm_with_acc,
        annot=labels_with_acc,
        fmt='',
        cmap='Blues',
        xticklabels=class_names_with_acc,
        yticklabels=class_names
    )
    plt.xlabel('Prediction label')
    plt.ylabel('Real label')
    plt.title(f'confusion matrix of {model_save_name}')
    plt.tight_layout()
    plt.savefig(os.path.join(plots_dir, f"{model_save_name}_confusion_matrix.png"))
    plt.close()
    print(f"混淆矩阵已保存到: {os.path.join(plots_dir, f'{model_save_name}_confusion_matrix.png')}")
    # ========== 混淆矩阵生成代码结束 ==========

    # 计算并保存每个类别的测试损失
    class_losses = test_per_class(model, test_loader, criterion, device, class_names, scaler)
    save_best_test_losses(class_losses, model_save_name, output_dir)

    print(f"\n训练完成: {model_save_name}")
    print(f"最佳验证准确率: {best_val_acc*100:.2f}%")

    return metrics